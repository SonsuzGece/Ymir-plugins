// @provider {"id":"yesilcamtv", "name":"YesilCamTv", "types":["movie"], "domain":"yesilcamtv.com.tr", "formats":["m3u8", "mp4"], "sample":"tt0297138:movie:1:1", "description":"Yeşilçam TV: klasik Türk filmleri; Rumble HLS kaliteleri ve doğrudan MP4 akışları.", "version":"1.0.12"}
/**
 * yesilcamtv — Nuvio provider (bb-nuvio).
 * Flow: Cinemeta title -> /?s= card -> film page -> rumble embed -> HLS qualities.
 */
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";
var BASE = "https://yesilcamtv.com.tr";

function text(url, referer) {
  var headers = { "User-Agent": UA, "Accept-Language": "tr-TR,tr;q=0.9" };
  if (referer) headers.Referer = referer;
  return fetch(url, { headers: headers }).then(function (r) {
    if (!r.ok) throw new Error("HTTP " + r.status + " " + url);
    return r.text();
  });
}

function fold(value) {
  return String(value || "").toLowerCase()
    .replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g")
    .replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c")
    .replace(/[^a-z0-9]+/g, " ").trim();
}

function titleOf(id, mediaType) {
  if (/^__alt__:/.test(String(id))) return Promise.resolve(decodeURIComponent(String(id).slice(8)));
  var kind = mediaType === "tv" ? "series" : "movie";
  return fetch("https://v3-cinemeta.strem.io/meta/" + kind + "/" + id + ".json")
    .then(function (r) { return r.json(); })
    .then(function (j) { return String((j.meta || {}).name || "").trim(); })
    .catch(function () { return ""; });
}

function parseCards(page) {
  var re = /<div class="poster">\s*<a href="(https:\/\/yesilcamtv\.com\.tr\/[^"]+)"[^>]*>[\s\S]{0,700}?alt="([^"]*)"/g;
  var m, cards = [];
  while ((m = re.exec(page)) !== null) {
    if (/\/(?:category|tag|oyuncu|yil|page|wp-|login|uye-ol|giris)\b/i.test(m[1])) continue;
    cards.push({ url: m[1], label: fold(m[2]) });
  }
  return cards;
}

/* Site araması Türkçe harflere duyarlı ("Gelinlik Kızlar" ≠ "Gelinlik Kizlar");
   bu yüzden sorgu sırayla tam başlık, en uzun kelime ve katlanmış haliyle denenir. */
function bestCard(cards, term) {
  var want = term.split(" ").filter(function (w) { return w.length > 2; });
  var best = null, bestScore = 0, i, j, hit;
  for (i = 0; i < cards.length; i++) {
    var label = cards[i].label.split(" ");
    hit = 0;
    for (j = 0; j < want.length; j++) if (label.indexOf(want[j]) !== -1) hit++;
    if (hit > bestScore) { bestScore = hit; best = cards[i]; }
  }
  return best && bestScore >= want.length ? best.url : null;
}

function tryQuery(query, term) {
  return text(BASE + "/?s=" + encodeURIComponent(query)).then(function (page) {
    return bestCard(parseCards(page), term);
  });
}

function filmUrl(title) {
  var term = fold(title);
  if (!term) return Promise.resolve(null);
  var words = String(title).split(/\s+/).filter(Boolean);
  var longest = words.slice().sort(function (a, b) { return b.length - a.length; })[0] || "";
  var queries = [title];
  if (longest && longest !== title) queries.push(longest);
  if (term !== title) queries.push(term);
  var i = 0;
  function next() {
    if (i >= queries.length) return null;
    return tryQuery(queries[i++], term).then(function (hit) {
      return hit || next();
    });
  }
  return Promise.resolve().then(next);
}

/* Rumble embed HTML carries "<key>":{"url":...,"meta":{...w,h}} per quality. */
function rumbleRows(page, add) {
  var ids = [];
  var re = /rumble\.com\/embed\/([^\/"'?#]+)/g;
  var m;
  while ((m = re.exec(page)) !== null) if (ids.indexOf(m[1]) === -1) ids.push(m[1]);
  var watchM = /https?:\/\/(?:www\.)?rumble\.com\/v[0-9a-zA-Z]+-[^\/"'?#\s<>]+/.exec(page);
  var resolveId = ids.length ? Promise.resolve(ids[0]) : (watchM ? text("https://rumble.com/api/Media/oembed.json?url=" + encodeURIComponent(watchM[0])).then(function (j) {
    var em = /rumble\.com\\?\/embed\\?\/([^\\\/"'?#]+)/.exec(j);
    return em ? em[1] : null;
  }).catch(function () { return null; }) : Promise.resolve(null));
  return resolveId.then(function (id) {
    if (!id) return;
    return text("https://rumble.com/embed/" + id + "/", "https://rumble.com/").then(function (embed) {
      var uaSection = embed.split("\"timeline\"")[0];
      var media = /"(\d+|tar|mp4)":\{"url":"(https:[^"]+?)","meta":\{"bitrate":\d+,"size":\d+,"w":\d+,"h":(\d+)/g;
      var mp4 = [];
      var hit, hlsCount = 0;
      while ((hit = media.exec(uaSection)) !== null) {
        var u = hit[2].replace(/\\\//g, "/");
        var height = parseInt(hit[3], 10) || 0;
        var q = height ? height + "p" : "auto";
        if (u.indexOf("r_file=chunklist.m3u8") !== -1) {
          add(u, q, "https://rumble.com/");
          hlsCount++;
        } else if (/\.mp4(\?|$)/i.test(u) && height >= 240) {
          mp4.push([u, q]);
        }
      }
      if (!hlsCount) {
        for (var k = 0; k < mp4.length; k++) add(mp4[k][0], mp4[k][1], "https://rumble.com/");
      }
    });
  });
}

function getStreams(imdbId, mediaType, season, episode) {
  var pageUrl = null;
  var directHref = (typeof imdbId === "string" && imdbId.indexOf("__href__:") === 0)
    ? decodeURIComponent(imdbId.slice(9)) : null;
  return (directHref ? Promise.resolve(directHref.indexOf("http") === 0 ? directHref : BASE + directHref) : titleOf(imdbId, mediaType)
    .then(function (title) {
      return filmUrl(title);
    }))
    .then(function (url) {
      if (!url) return [];
      pageUrl = url;
      return text(url);
    })
    .then(function (page) {
      if (!page) return [];
      var rows = [];
      var seen = {};
      var seenQ = {};
      function add(url, quality, referer) {
        var hls = /\.m3u8|chunklist|\.tar(\?|$)/i.test(url) && !/\.mp4(\?|$)/i.test(url);
        var marked = hls && url.indexOf("#") === -1 ? url + "#.m3u8" : url;
        if (!/^https?:/.test(url) || seen[url] || seenQ[quality]) return;
        seen[url] = 1;
        seenQ[quality] = 1;
        rows.push({
          name: "yesilcamtv",
          title: "YesilCamTv - " + quality + (hls ? " [HLS]" : " [MP4]"),
          url: marked,
          quality: quality + (hls ? "" : " [MP4]"),
          headers: { Referer: referer, "User-Agent": UA },
          subtitles: []
        });
      }
      return rumbleRows(page, add).then(function () {
        var direct = /https?:\/\/[^"'\s<>]+?\.(?:m3u8|mp4)(?:\?[^"'\s<>]*)?/g;
        var m;
        while ((m = direct.exec(page)) !== null) add(m[0], "auto", pageUrl);
        var ifrChain = Promise.resolve();
        if (!rows.length) {
          var ifrRe = /<iframe[^>]+(?:data-src|src)="([^"]+)"/gi, fm, fList = [];
          while ((fm = ifrRe.exec(page)) !== null) fList.push(fm[1]);
          fList.slice(0, 4).forEach(function (src) {
            ifrChain = ifrChain.then(function () {
              var u = src.indexOf("//") === 0 ? "https:" + src : src;
              if (u.indexOf("http") !== 0 || /rumble\.com/i.test(u)) return;
              if (/ok\.ru|odnoklassniki/i.test(u)) {
                var mid = (/videoembed\/(\d+)/.exec(u) || /video\/(\d+)/.exec(u) || [])[1];
                if (!mid) return;
                return fetch("https://ok.ru/dk?cmd=videoPlayerMetadata&mid=" + mid, { method: "POST", headers: { "User-Agent": UA, "Referer": "https://ok.ru/" } })
                  .then(function (r) { return r.json(); })
                  .then(function (j) { (j && j.videos || []).forEach(function (v) { if (v && v.url) add(v.url, v.name || "OkRu", "https://ok.ru/"); }); })
                  .catch(function () {});
              }
              return text(u, { referer: pageUrl }).then(function (ih) {
                var clean = ih.replace(/\\\//g, "/"), mm;
                var re2 = /https?:\/\/[^"'\s<>\\]+\.(?:m3u8|mp4)(?:\?[^"'\s<>\\]*)?/gi;
                while ((mm = re2.exec(clean)) !== null) add(mm[0], "Embed", u);
              }).catch(function () {});
            });
          });
        }
        return ifrChain.then(function () {
          rows.sort(function (a, b) {
            return (parseInt(b.quality, 10) || 0) - (parseInt(a.quality, 10) || 0);
          });
          return rows.slice(0, 6);
        });
      });
    })
    .catch(function (e) {
      console.log("[bb-nuvio][yesilcamtv] " + (e && e.message));
      return [];
    });
}

module.exports = { getStreams };


/* NuvioMobile always calls getStreams with args.tmdbId (JsBindings.kt); the
   value is a numeric TMDB id after TmdbService.ensureTmdbId. Resolve it to
   IMDb so the existing Cinemeta/title flow keeps working. */
var __origGetStreams = module.exports.getStreams;
module.exports.getStreams = function (id, mediaType, season, episode) {
  var raw = String(id || "");
  if (!/^\d+$/.test(raw)) return __origGetStreams(raw, mediaType, season, episode);
  var tv = mediaType !== "movie";
  var headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36", "Accept": "application/json" };
  var key = typeof TMDB_API_KEY !== "undefined" ? TMDB_API_KEY : "";
  var api = "https://www.wikidata.org/w/api.php?format=json";
  var prop = tv ? "P4983" : "P4947";
  function fromTmdb() {
    if (!key) return Promise.resolve("");
    return fetch("https://api.themoviedb.org/3/" + (tv ? "tv" : "movie") + "/" + raw + "/external_ids?api_key=" + encodeURIComponent(key), { headers: headers })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (json) { return String((json && json.imdb_id) || ""); })
      .catch(function () { return ""; });
  }
  function fromWikidata() {
    return fetch(api + "&action=query&list=search&srlimit=1&srsearch=" + encodeURIComponent("haswbstatement:" + prop + "=" + raw), { headers: headers })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (json) {
        var hits = (json && json.query && json.query.search) || [];
        if (!hits.length) return "";
        return fetch(api + "&action=wbgetentities&props=claims&ids=" + hits[0].title, { headers: headers });
      })
      .then(function (r) { return r && r.ok ? r.json() : null; })
      .then(function (json) {
        var entities = (json && json.entities) || {};
        for (var entity in entities) {
          var rows = ((entities[entity] || {}).claims || {}).P345 || [];
          for (var i = 0; i < rows.length; i++) {
            var value = rows[i] && rows[i].mainsnak && rows[i].mainsnak.datavalue && rows[i].mainsnak.datavalue.value;
            if (/^tt\d+$/.test(String(value || ""))) return value;
          }
        }
        return "";
      })
      .catch(function () { return ""; });
  }
  return fromTmdb().then(function (imdb) { return imdb || fromWikidata(); }).then(function (imdb) {
    return __origGetStreams(imdb || raw, mediaType, season, episode);
  }).catch(function () { return []; });
};

/* Cinemeta basligi yerellestirir ("Gibi" -> "As If"); sonuc bossa Wikidata TR/EN basliklariyla yeniden dene. */
function __altTitles(raw, mediaType) {
  var h = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36", "Accept": "application/json" };
  var api = "https://www.wikidata.org/w/api.php?format=json";
  var stmt = /^tt\d+$/.test(raw) ? "P345=" + raw : (mediaType === "movie" ? "P4947=" : "P4983=") + raw;
  var wd = fetch(api + "&action=query&list=search&srlimit=1&srsearch=" + encodeURIComponent("haswbstatement:" + stmt), { headers: h })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (j) {
      var hits = (j && j.query && j.query.search) || [];
      if (!hits.length) return null;
      return fetch(api + "&action=wbgetentities&props=labels|aliases&languages=tr|en&ids=" + hits[0].title, { headers: h }).then(function (r) { return r.ok ? r.json() : null; });
    })
    .then(function (j) {
      var res = [], ents = (j && j.entities) || {}, k, l, a, i;
      for (k in ents) {
        l = ents[k].labels || {}; a = ents[k].aliases || {};
        if (l.tr && l.tr.value) res.push(l.tr.value);
        if (l.en && l.en.value) res.push(l.en.value);
        for (i = 0; i < (a.tr || []).length && i < 2; i++) res.push(a.tr[i].value);
      }
      return res;
    }).catch(function () { return []; });
  var imdb = /^tt\d+$/.test(raw)
    ? fetch("https://v3.sg.media-imdb.com/suggestion/t/" + raw + ".json", { headers: h })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) { return (j && j.d && j.d[0] && j.d[0].l) ? [j.d[0].l] : []; })
        .catch(function () { return []; })
    : Promise.resolve([]);
  var tvm = /^tt\d+$/.test(raw) && mediaType !== "movie"
    ? fetch("https://api.tvmaze.com/lookup/shows?imdb=" + raw, { headers: h })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) { return (j && j.name) ? [j.name] : []; })
        .catch(function () { return []; })
    : Promise.resolve([]);
  return Promise.all([wd, imdb, tvm]).then(function (lists) {
    var out = [], seen = {};
    for (var i = 0; i < lists.length; i++) {
      for (var j = 0; j < lists[i].length; j++) {
        var v = String(lists[i][j] || "").replace(/\s*\([^)]*\)\s*$/, "").trim();
        if (v && !seen[v.toLowerCase()]) { seen[v.toLowerCase()] = 1; out.push(v); }
      }
    }
    return out;
  });
}
var __cinemetaGetStreams = module.exports.getStreams;
module.exports.getStreams = function (id, mediaType, season, episode) {
  var raw = String(id || "");
  return __cinemetaGetStreams(raw, mediaType, season, episode).then(function (streams) {
    if ((streams && streams.length) || /^__alt__:/.test(raw)) return streams || [];
    return __altTitles(raw, mediaType).then(function (titles) {
      var chain = Promise.resolve([]);
      titles.forEach(function (t) {
        chain = chain.then(function (out) {
          return out.length ? out : __cinemetaGetStreams("__alt__:" + encodeURIComponent(t), mediaType, season, episode);
        });
      });
      return chain;
    });
  }).catch(function () { return []; });
};

/* Dil etiketi (AGENTS.md): Nuvio karti "quality \u2022 ..." satirini gosterir; dil etiketi kalitenin yanina yazilir.
   Kanit: baslikta dublaj/altyazi, akisa eklenmis altyazi dosyasi ya da sitenin yalniz altyazili olmasi. Kanit yoksa etiket yok. */
var __subOnly = false;
var __langLabeled = module.exports.getStreams;
module.exports.getStreams = function (id, mediaType, season, episode) {
  return __langLabeled.apply(this, arguments).then(function (streams) {
    return (streams || []).map(function (s) {
      if (!s) return s;
      var hay = String(s.title || "") + " " + String(s.name || "");
      var tags = [];
      if (/dublaj/i.test(hay)) tags.push("TR Dublaj");
      if (/altyaz/i.test(hay) || (s.subtitles && s.subtitles.length) || (!tags.length && __subOnly)) tags.push("Altyaz\u0131l\u0131");
      if (!tags.length) return s;
      var q = String(s.quality || "").replace(/\s*\u2022.*$/, "") || "auto";
      s.quality = q + " \u2022 " + tags.join(" \u2022 ");
      return s;
    });
  });
};


/* ===================================================================
 *  Ymir adapter (bb-nuvio): catalog from addon config (parsing mirrors
 *  bigbull build.mjs), __alt__ title bridge into the bb getStreams above.
 * =================================================================== */
;(function () {
  var __CFG = {"id":"yesilcamtv","name":"Yeşilçam TV","type":"movie","url":"https://yesilcamtv.com.tr/","item":"<div class=\"movie-box\"[\\s\\S]*?class=\"film-ismi\">[\\s\\S]*?</a>","title":"class=\"film-ismi\">\\s*<a[^>]*>([^<]+)</a>","limit":40};
  var __SERIES = false;
  var __UA = (typeof UA !== 'undefined' && UA) ? UA :
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";
  function __fetch(u) {
    return fetch(u, { headers: { "User-Agent": __UA, "Accept-Language": "tr-TR,tr;q=0.9" } })
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status + " " + u); return r.text(); });
  }
  var __ENT = { amp:"&", lt:"<", gt:">", quot:'"', apos:"'", nbsp:" ", ouml:"ö", uuml:"ü", Ouml:"Ö", Uuml:"Ü" };
  function __stripTags(h) {
    return String(h || "")
      .replace(/<[^>]*>/g, " ")
      .replace(/&([a-zA-Z]{2,8});/g, function (m, k) { return __ENT[k] != null ? __ENT[k] : m; })
      .replace(/&#x([0-9a-fA-F]+);/g, function (_, x) { return String.fromCharCode(parseInt(x, 16)); })
      .replace(/&#(\d+);/g, function (_, d) { return String.fromCharCode(+d); })
      .replace(/\s+/g, " ").trim();
  }
  function __origin(u) { var m = /^(https?:\/\/[^/]+)/.exec(u); return m ? m[1] : ""; }
  async function getCatalog(args) {
    var q = args && args.query ? String(args.query).trim() : "";
    if (q) {
      return { items: [{ id: "__alt__:" + encodeURIComponent(q), name: q, poster: null,
        type: __SERIES ? "tv" : "movie" }] };
    }
    var html = await __fetch(__CFG.url);
    if (__CFG.unescape) html = html.replace(/\\"/g, '"');
    var blocks = html.match(new RegExp(__CFG.item, "gi")) || [];
    var titleRe = new RegExp(__CFG.title, "i");
    var items = [], seen = {};
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      var mm = titleRe.exec(b);
      var title = mm ? __stripTags(mm[1]) : "";
      if (__CFG.strip) title = title.replace(new RegExp(__CFG.strip, "i"), "").trim();
      if (!title || title.length < 2) continue;
      var key = title.toLowerCase();
      if (seen[key]) continue; seen[key] = 1;
      var poster = __CFG.poster ? ((new RegExp(__CFG.poster, "i").exec(b) || [])[1]) : null;
      if (poster && /^data:/i.test(poster)) poster = null;
      if (poster && poster.charAt(0) === "/") poster = __origin(__CFG.url) + poster;
      if (poster) poster = __stripTags(poster);
      var hrefM = __CFG.href ? new RegExp(__CFG.href, "i").exec(b) : null;
      var itemHref = hrefM && hrefM[1] ? hrefM[1].replace(/\\\//g, "/") : "";
      var itemId = itemHref ? ("__href__:" + encodeURIComponent(itemHref)) : ("__alt__:" + encodeURIComponent(title));
      items.push({ id: itemId, name: title, poster: poster || null,
        type: __SERIES ? "tv" : "movie" });
      if (__CFG.limit && items.length >= __CFG.limit) break;
      if (items.length >= 100) break;
    }
    if (!items.length) throw new Error("katalog boş: item regex eşleşmedi (" + __CFG.url + ")");
    return { items: items };
  }
  async function search(args) { return getCatalog(args); }

  // Series: synthetic season/episode grid so episodes are navigable; the bb
  // getStreams resolves whichever S/E actually exists on the site.
  async function getMeta(args) {
    var id = args && args.id;
    var title = /^__alt__:/.test(String(id)) ? decodeURIComponent(String(id).slice(8)) : String(id || "");
    var videos = [];
    var SEASONS = 3, EP = 30;
    for (var s = 1; s <= SEASONS; s++) {
      for (var e = 1; e <= EP; e++) {
        videos.push({ id: id, title: s + ". Sezon " + e + ". Bölüm", season: s, episode: e });
      }
    }
    return { meta: { id: id, type: "series", name: title, videos: videos } };
  }

  var __bbGetStreams = module.exports.getStreams;
  async function getStreams(tmdbId, mediaType, season, episode, url) {
    var id = url || tmdbId;
    return __bbGetStreams(id, __SERIES ? "tv" : "movie", season, episode);
  }
  var __exports = { getCatalog: getCatalog, getStreams: getStreams, search: search };
  if (__SERIES) __exports.getMeta = getMeta;
  module.exports = __exports;
  if (typeof globalThis !== 'undefined') {
    globalThis.getCatalog = getCatalog; globalThis.getStreams = getStreams; globalThis.search = search;
    if (__SERIES) globalThis.getMeta = getMeta;
  }
})();
