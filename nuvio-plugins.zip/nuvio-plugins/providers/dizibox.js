'use strict';

// DiziBox provider for Nuvio
// Turkish TV series streaming site

const PROVIDER_ID = 'dizibox';
const FALLBACK_DOMAIN = 'https://www.dizibox.live';
const DOMAINS_URL = 'https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/nuvio-plugins/refs/heads/main/domains.json';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36';

let _cachedDomain = null;

async function getDomain() {
  if (_cachedDomain) return _cachedDomain;
  try {
    const url = (typeof DOMAINS !== 'undefined' && DOMAINS) ? DOMAINS : DOMAINS_URL;
    const res = await fetch(url, { headers: { 'User-Agent': UA } });
    const domains = await res.json();
    _cachedDomain = (domains[PROVIDER_ID] || FALLBACK_DOMAIN).replace(/\/$/, '');
  } catch (e) {
    _cachedDomain = FALLBACK_DOMAIN;
  }
  return _cachedDomain;
}

async function get(url) {
  const domain = await getDomain();
  const res = await fetch(url, {
    headers: {
      'User-Agent': UA,
      'Accept': 'text/html,application/xhtml+xml,*/*',
      'Accept-Language': 'tr-TR,tr;q=0.9',
      'Referer': domain + '/',
    },
  });
  if (!res.ok) throw new Error('HTTP ' + res.status + ': ' + url);
  return res.text();
}

function decodeEntities(str) {
  if (!str) return '';
  return str
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
}

function extractAll(html, regex) {
  const results = [];
  let m;
  const r = new RegExp(regex.source, 'g');
  while ((m = r.exec(html)) !== null) results.push(m);
  return results;
}

const CATALOGS = [
  { id: 'series_latest', name: 'Son Eklenenler', path: '/page/' },
  { id: 'series_action', name: 'Aksiyon Dizileri', path: '/kategori/aksiyon/page/' },
  { id: 'series_drama', name: 'Dram Dizileri', path: '/kategori/dram/page/' },
  { id: 'series_comedy', name: 'Komedi Dizileri', path: '/kategori/komedi/page/' },
  { id: 'series_turkish', name: 'Türk Dizileri', path: '/kategori/turk-dizi/page/' },
];

// --- getCatalog ---
async function getCatalog({ catalogId, pageToken }) {
  const domain = await getDomain();
  const page = pageToken ? parseInt(pageToken) : 1;

  const cat = CATALOGS.find(c => c.id === catalogId) || CATALOGS[0];
  const url = domain + cat.path + page + '/';

  const html = await get(url);
  const items = [];

  const matches = extractAll(html, /<div[^>]*class="[^"]*(?:item|card|series)[^"]*"[^>]*>([\s\S]*?)<\/div>/);
  for (const m of matches) {
    const block = m[0];
    const hrefM = block.match(/href="([^"]+)"/);
    const titleM = block.match(/(?:title|alt)="([^"]+)"/);
    const srcM = block.match(/data-src="([^"]+)"|src="([^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/i);

    if (!hrefM || !titleM) continue;
    const href = hrefM[1];
    if (!href.includes(domain) && !href.startsWith('/')) continue;

    const title = titleM[1];
    const poster = srcM ? (srcM[1] || srcM[2]) : '';
    const id = href.replace(domain, '').replace(/^\/|\/$/g, '');

    if (title && id && title.length < 100) {
      items.push({
        id: id,
        title: decodeEntities(title),
        poster: poster,
        type: 'tv',
        year: null,
      });
    }
  }

  const hasNext = html.includes('class="next') || html.includes('rel="next"');
  return {
    items,
    nextPageToken: hasNext ? String(page + 1) : null,
  };
}

// --- search ---
async function search({ query }) {
  const domain = await getDomain();
  const url = domain + '/?s=' + encodeURIComponent(query);
  const html = await get(url);
  const items = [];

  const matches = extractAll(html, /<div[^>]*class="[^"]*(?:item|card|series)[^"]*"[^>]*>([\s\S]*?)<\/div>/);
  for (const m of matches) {
    const block = m[0];
    const hrefM = block.match(/href="([^"]+)"/);
    const titleM = block.match(/(?:title|alt)="([^"]+)"/);
    const srcM = block.match(/data-src="([^"]+)"|src="([^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/i);

    if (!hrefM || !titleM) continue;
    const title = titleM[1];
    const poster = srcM ? (srcM[1] || srcM[2]) : '';
    const id = hrefM[1].replace(domain, '').replace(/^\/|\/$/g, '');

    if (title && id && title.length < 100) {
      items.push({ id, title: decodeEntities(title), poster, type: 'tv', year: null });
    }
  }

  return { items };
}

// --- getStreams ---
async function getStreams(tmdbId, mediaType, season, episode, contentUrl) {
  const domain = await getDomain();
  let pageUrl = contentUrl;

  if (!pageUrl) return [];

  // For series, build episode URL
  let episodeUrl = pageUrl;
  if (season && episode) {
    // Try: /dizi-adi/sezon-N/bolum-M/
    const base = pageUrl.replace(/\/$/, '');
    episodeUrl = base + '/sezon-' + season + '/bolum-' + episode + '/';
  }

  let html;
  try {
    html = await get(episodeUrl);
  } catch (e) {
    try { html = await get(pageUrl); } catch (e2) { return []; }
  }

  const streams = [];

  const iframeRe = /<iframe[^>]+src="([^"]+)"/g;
  let m;
  while ((m = iframeRe.exec(html)) !== null) {
    const src = m[1];
    if (src.includes('javascript') || src.length < 10) continue;
    streams.push({
      name: 'DiziBox',
      title: 'Kaynak',
      description: 'DiziBox embed',
      url: src,
      format: 'iframe',
      headers: { 'Referer': domain + '/', 'User-Agent': UA },
      subtitles: [],
    });
  }

  const videoRe = /(?:file|src)\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/g;
  while ((m = videoRe.exec(html)) !== null) {
    const videoUrl = m[1].startsWith('//') ? 'https:' + m[1] : m[1];
    if (!videoUrl.startsWith('http')) continue;
    streams.push({
      name: 'DiziBox',
      title: videoUrl.includes('m3u8') ? 'HLS' : 'MP4',
      description: 'Direct video',
      url: videoUrl,
      format: videoUrl.includes('m3u8') ? 'hls' : 'mp4',
      headers: { 'Referer': domain + '/', 'User-Agent': UA },
      subtitles: [],
    });
  }

  return streams;
}

module.exports = { getCatalog, search, getStreams };
