'use strict';

// HDFilmCehennemi provider for Nuvio
// Turkish movie & series streaming site

const PROVIDER_ID = 'hdfilmcehennemi';
const FALLBACK_DOMAIN = 'https://www.hdfilmcehennemi.nl';
const DOMAINS_URL = 'https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/nuvio-plugins/refs/heads/main/domains.json';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36';

let _cachedDomain = null;

async function getDomain() {
  if (_cachedDomain) return _cachedDomain;
  try {
    const url = (typeof DOMAINS !== 'undefined' && DOMAINS) ? DOMAINS : DOMAINS_URL;
    const res = await fetch(url, { headers: { 'User-Agent': UA } });
    const domains = await res.json();
    _cachedDomain = (domains[PROVIDER_ID] || FALLBACK_DOMAIN).replace(/\/$/, '');
  } catch (e) {
    _cachedDomain = FALLBACK_DOMAIN;
  }
  return _cachedDomain;
}

async function get(url) {
  const domain = await getDomain();
  const res = await fetch(url, {
    headers: {
      'User-Agent': UA,
      'Accept': 'text/html,application/xhtml+xml,*/*',
      'Accept-Language': 'tr-TR,tr;q=0.9',
      'Referer': domain + '/',
    },
  });
  if (!res.ok) throw new Error('HTTP ' + res.status + ': ' + url);
  return res.text();
}

function decodeEntities(str) {
  if (!str) return '';
  return str
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}

function extractAll(html, regex) {
  const results = [];
  let m;
  const r = new RegExp(regex.source, 'g');
  while ((m = r.exec(html)) !== null) results.push(m);
  return results;
}

function buildItem(id, title, poster, type, year) {
  return {
    id: id,
    title: decodeEntities(title),
    poster: poster || '',
    type: type,
    year: year || null,
  };
}

// --- getCatalog ---
async function getCatalog({ catalogId, type, pageToken }) {
  const domain = await getDomain();
  const page = pageToken ? parseInt(pageToken) : 1;
  let url;

  if (catalogId === 'movies_latest') {
    url = domain + '/page/' + page + '/';
  } else if (catalogId === 'series_latest') {
    url = domain + '/dizi/page/' + page + '/';
  } else if (catalogId === 'movies_imdb') {
    url = domain + '/imdb-top-250/page/' + page + '/';
  } else {
    url = domain + '/page/' + page + '/';
  }

  const html = await get(url);
  const items = [];

  // Parse film cards: <article ...><a href="URL"><img ... title="TITLE" src="POSTER">
  const cardRe = /<article[^>]*class="[^"]*movie[^"]*"[^>]*>[\s\S]*?<a[^>]+href="([^"]+)"[^>]*>[\s\S]*?<img[^>]+(?:title="([^"]*)"[^>]+src="([^"]+)"|src="([^"]+)"[^>]+title="([^"]*)")[\s\S]*?<\/article>/;
  const matches = extractAll(html, /<article[^>]*>([\s\S]*?)<\/article>/);

  for (const m of matches) {
    const block = m[0];
    const hrefM = block.match(/href="([^"]+)"/);
    const titleM = block.match(/(?:title|alt)="([^"]+)"/);
    const srcM = block.match(/data-src="([^"]+)"|src="([^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/i);
    const yearM = block.match(/\b(19|20)\d{2}\b/);

    if (!hrefM || !titleM) continue;
    const href = hrefM[1];
    const title = titleM[1];
    const poster = srcM ? (srcM[1] || srcM[2]) : '';
    const isMovie = !href.includes('/dizi/') && !href.includes('/sezon/');
    const itemType = isMovie ? 'movie' : 'tv';
    const id = href.replace(domain, '').replace(/^\/|\/$/g, '');

    if (title && id) {
      items.push(buildItem(id, title, poster, itemType, yearM ? yearM[0] : null));
    }
  }

  const hasNext = html.includes('class="next') || html.includes('rel="next"');
  return {
    items,
    nextPageToken: hasNext ? String(page + 1) : null,
  };
}

// --- search ---
async function search({ query }) {
  const domain = await getDomain();
  const url = domain + '/?s=' + encodeURIComponent(query);
  const html = await get(url);
  const items = [];

  const matches = extractAll(html, /<article[^>]*>([\s\S]*?)<\/article>/);
  for (const m of matches) {
    const block = m[0];
    const hrefM = block.match(/href="([^"]+)"/);
    const titleM = block.match(/(?:title|alt)="([^"]+)"/);
    const srcM = block.match(/data-src="([^"]+)"|src="([^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/i);

    if (!hrefM || !titleM) continue;
    const href = hrefM[1];
    const title = titleM[1];
    const poster = srcM ? (srcM[1] || srcM[2]) : '';
    const isMovie = !href.includes('/dizi/') && !href.includes('/sezon/');
    const id = href.replace(domain, '').replace(/^\/|\/$/g, '');

    if (title && id) {
      items.push(buildItem(id, title, poster, isMovie ? 'movie' : 'tv', null));
    }
  }

  return { items };
}

// --- getStreams ---
async function getStreams(tmdbId, mediaType, season, episode, contentUrl) {
  const domain = await getDomain();
  let pageUrl = contentUrl;

  if (!pageUrl) {
    // Try to find via TMDB id: search by tmdbId
    const searchHtml = await get(domain + '/?s=' + tmdbId).catch(() => '');
    const hrefM = searchHtml.match(/href="(https?:\/\/[^"]*hdfilmcehennemi[^"]*\/[^"]+)"/);
    if (hrefM) pageUrl = hrefM[1];
    if (!pageUrl) return [];
  }

  const html = await get(pageUrl);
  const streams = [];

  // Find iframe/embed sources
  const iframeRe = /<iframe[^>]+src="([^"]+)"/g;
  let m;
  while ((m = iframeRe.exec(html)) !== null) {
    const src = m[1];
    if (src.includes('javascript') || src.length < 10) continue;
    streams.push({
      name: 'HDFilmCehennemi',
      title: 'Kaynak 1',
      description: 'HDFilmCehennemi embed',
      url: src,
      format: 'iframe',
      headers: { 'Referer': domain + '/', 'User-Agent': UA },
      subtitles: [],
    });
  }

  // Find direct video sources
  const videoRe = /(?:file|src)\s*:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/g;
  while ((m = videoRe.exec(html)) !== null) {
    const url = m[1];
    if (url.startsWith('//')) {
      streams.push({
        name: 'HDFilmCehennemi',
        title: url.includes('m3u8') ? 'HLS' : 'MP4',
        description: 'Direct video',
        url: 'https:' + url,
        format: url.includes('m3u8') ? 'hls' : 'mp4',
        headers: { 'Referer': domain + '/', 'User-Agent': UA },
        subtitles: [],
      });
    } else if (url.startsWith('http')) {
      streams.push({
        name: 'HDFilmCehennemi',
        title: url.includes('m3u8') ? 'HLS' : 'MP4',
        description: 'Direct video',
        url: url,
        format: url.includes('m3u8') ? 'hls' : 'mp4',
        headers: { 'Referer': domain + '/', 'User-Agent': UA },
        subtitles: [],
      });
    }
  }

  return streams;
}

module.exports = { getCatalog, search, getStreams };
