#!/bin/bash
# Kullanıcı adını değiştirme scripti
# Kullanım: bash setup.sh KULLANICIADIN

USERNAME=$1

if [ -z "$USERNAME" ]; then
  echo "Kullanım: bash setup.sh GITHUB_KULLANICIADIN"
  echo "Örnek: bash setup.sh johndoe"
  exit 1
fi

echo "Kullanıcı adı değiştiriliyor: YOUR_GITHUB_USERNAME -> $USERNAME"

# Tüm dosyalarda YOUR_GITHUB_USERNAME'i değiştir
find . -type f \( -name "*.js" -o -name "*.json" -o -name "*.md" -o -name "*.yml" \) | while read -r file; do
  sed -i "s/YOUR_GITHUB_USERNAME/$USERNAME/g" "$file"
  echo "  Güncellendi: $file"
done

echo ""
echo "Tamamlandı! Artık şu komutu çalıştırabilirsiniz:"
echo "  git add ."
echo "  git commit -m 'Initial plugin setup'"
echo "  git push"
echo ""
echo "GitHub Pages aktif olunca manifest URL:"
echo "  https://$USERNAME.github.io/nuvio-plugins/manifest.json"
