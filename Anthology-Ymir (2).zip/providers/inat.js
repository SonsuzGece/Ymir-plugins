/*
 * İnat (İnatBox) provider for Nuvio / Ymir Player
 * -------------------------------------------------
 * Reverse-engineered from the official app's encrypted API.
 *
 * Architecture (fully domain-rotation proof — only the gateway is fixed):
 *   1. POST https://speedrestapi.com/rest/api/   (stable gateway)
 *        body: 1=<16charkey>&0=<16charkey>
 *        -> AES double-decrypt -> { DC2: "<current ct.php url>", ... }
 *   2. POST <ct.php>  -> categories [{catName, catUrl, catType, catImg}]
 *   3. POST <catUrl>  -> content (series / channels)
 *        series -> seasons -> episodes (recursive via diziType === "dizi_mode")
 *   4. GET  <chUrl> (with chHeaders) -> encrypted blob
 *        -> decrypt with chReg.Regex1 then chReg.Regex2 -> { chUrl: "<m3u8>" }
 *
 * Crypto: AES-128-CBC, key === IV, PKCS7. Pure-JS (QuickJS has no crypto).
 *   - Main responses:  double-decrypt, key = IV = the request key (both passes)
 *   - Stream blob:     double-decrypt, pass1 key=IV=Regex1, pass2 key=IV=Regex2
 *
 * All of the above verified byte-for-byte against a real HAR capture.
 *
 * Each İnat category is exposed as its own scraper (SCRAPER_ID -> catName),
 * which maps cleanly onto the flat catalog -> item -> (meta) -> stream model.
 */
'use strict';

/* =========================================================================
 *  Embedded AES-CBC (128/256) + PKCS7  — verified against Node crypto & HAR
 * ========================================================================= */
var AES = (function () {
  var S = [], SI = [], RCON = [];
  (function () {
    var p = 1, q = 1;
    do {
      p = p ^ (p << 1) ^ ((p & 0x80) ? 0x11B : 0); p &= 0xFF;
      q ^= q << 1; q ^= q << 2; q ^= q << 4; q &= 0xFF; if (q & 0x80) q ^= 0x09;
      var x = q ^ ((q << 1) | (q >> 7)) ^ ((q << 2) | (q >> 6)) ^ ((q << 3) | (q >> 5)) ^ ((q << 4) | (q >> 4));
      x &= 0xFF;
      S[p] = (x ^ 0x63) & 0xFF;
    } while (p !== 1);
    S[0] = 0x63;
    for (var i = 0; i < 256; i++) SI[S[i]] = i;
    var r = 1;
    for (var j = 0; j < 20; j++) { RCON[j] = r; r = (r << 1) ^ ((r & 0x80) ? 0x11b : 0); r &= 0xff; }
  })();
  function mul(a, b) {
    var p = 0;
    for (var i = 0; i < 8; i++) {
      if (b & 1) p ^= a;
      var hi = a & 0x80; a = (a << 1) & 0xff; if (hi) a ^= 0x1b;
      b >>= 1;
    }
    return p & 0xff;
  }
  function expandKey(key) {
    var Nk = key.length / 4, Nr = Nk + 6;
    var w = new Array(4 * (Nr + 1));
    for (var i = 0; i < Nk; i++) w[i] = [key[4 * i], key[4 * i + 1], key[4 * i + 2], key[4 * i + 3]];
    for (i = Nk; i < 4 * (Nr + 1); i++) {
      var t = w[i - 1].slice();
      if (i % Nk === 0) {
        t = [t[1], t[2], t[3], t[0]];
        t = [S[t[0]], S[t[1]], S[t[2]], S[t[3]]];
        t[0] ^= RCON[i / Nk - 1];
      } else if (Nk > 6 && i % Nk === 4) {
        t = [S[t[0]], S[t[1]], S[t[2]], S[t[3]]];
      }
      w[i] = [w[i - Nk][0] ^ t[0], w[i - Nk][1] ^ t[1], w[i - Nk][2] ^ t[2], w[i - Nk][3] ^ t[3]];
    }
    return { w: w, Nr: Nr };
  }
  function decryptBlock(inp, ks) {
    var Nr = ks.Nr, w = ks.w;
    var s = [[], [], [], []];
    for (var i = 0; i < 16; i++) s[i % 4][(i / 4) | 0] = inp[i];
    addRoundKey(s, w, Nr);
    for (var round = Nr - 1; round >= 1; round--) {
      invShiftRows(s); invSubBytes(s); addRoundKey(s, w, round); invMixColumns(s);
    }
    invShiftRows(s); invSubBytes(s); addRoundKey(s, w, 0);
    var out = new Array(16);
    for (i = 0; i < 16; i++) out[i] = s[i % 4][(i / 4) | 0];
    return out;
  }
  function addRoundKey(s, w, round) {
    for (var c = 0; c < 4; c++) for (var r = 0; r < 4; r++) s[r][c] ^= w[round * 4 + c][r];
  }
  function invSubBytes(s) { for (var r = 0; r < 4; r++) for (var c = 0; c < 4; c++) s[r][c] = SI[s[r][c]]; }
  function invShiftRows(s) {
    for (var r = 1; r < 4; r++) {
      var row = [s[r][0], s[r][1], s[r][2], s[r][3]];
      for (var c = 0; c < 4; c++) s[r][c] = row[(c - r + 4) % 4];
    }
  }
  function invMixColumns(s) {
    for (var c = 0; c < 4; c++) {
      var a0 = s[0][c], a1 = s[1][c], a2 = s[2][c], a3 = s[3][c];
      s[0][c] = mul(a0, 14) ^ mul(a1, 11) ^ mul(a2, 13) ^ mul(a3, 9);
      s[1][c] = mul(a0, 9) ^ mul(a1, 14) ^ mul(a2, 11) ^ mul(a3, 13);
      s[2][c] = mul(a0, 13) ^ mul(a1, 9) ^ mul(a2, 14) ^ mul(a3, 11);
      s[3][c] = mul(a0, 11) ^ mul(a1, 13) ^ mul(a2, 9) ^ mul(a3, 14);
    }
  }
  function strToBytes(s) { var b = []; for (var i = 0; i < s.length; i++) b.push(s.charCodeAt(i) & 0xff); return b; }
  function decryptCBC(cipherBytes, keyBytes, ivBytes) {
    var ks = expandKey(keyBytes);
    var out = [];
    var prev = ivBytes.slice();
    for (var off = 0; off < cipherBytes.length; off += 16) {
      var block = cipherBytes.slice(off, off + 16);
      var dec = decryptBlock(block, ks);
      for (var i = 0; i < 16; i++) out.push(dec[i] ^ prev[i]);
      prev = block;
    }
    var pad = out[out.length - 1];
    if (pad > 0 && pad <= 16) out = out.slice(0, out.length - pad);
    return out;
  }
  function bytesToStr(b) { var s = ''; for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return s; }
  function bytesToUtf8(b) {
    try { return decodeURIComponent(escape(bytesToStr(b))); } catch (e) { return bytesToStr(b); }
  }
  return {
    decryptCBC: decryptCBC, strToBytes: strToBytes,
    bytesToStr: bytesToStr, bytesToUtf8: bytesToUtf8
  };
})();

function b64ToBytes(b64) {
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  b64 = String(b64).replace(/[^A-Za-z0-9+/=]/g, '');
  var bytes = [];
  for (var i = 0; i < b64.length; i += 4) {
    var e1 = chars.indexOf(b64[i]), e2 = chars.indexOf(b64[i + 1]);
    var e3 = chars.indexOf(b64[i + 2]), e4 = chars.indexOf(b64[i + 3]);
    var c1 = (e1 << 2) | (e2 >> 4);
    var c2 = ((e2 & 15) << 4) | (e3 >> 2);
    var c3 = ((e3 & 3) << 6) | e4;
    bytes.push(c1 & 0xff);
    if (b64[i + 2] !== '=') bytes.push(c2 & 0xff);
    if (b64[i + 3] !== '=') bytes.push(c3 & 0xff);
  }
  return bytes;
}

/* Main-response double decrypt: resp.split(':')[0] -> b64 -> AES(k,k) x2 */
function inatDecrypt(resp, keyStr) {
  var kb = AES.strToBytes(keyStr);
  var p1 = String(resp).split(':')[0];
  var s1 = AES.decryptCBC(b64ToBytes(p1), kb, kb);
  var p2 = AES.bytesToStr(s1).split(':')[0];
  var s2 = AES.decryptCBC(b64ToBytes(p2), kb, kb);
  return AES.bytesToUtf8(s2);
}

/* Stream blob double decrypt: pass1 key=IV=Regex1, pass2 key=IV=Regex2 */
function streamDecrypt(blob, r1, r2) {
  var k1 = AES.strToBytes(r1);
  var s1 = AES.decryptCBC(b64ToBytes(String(blob).split(':')[0]), k1, k1);
  var mid = AES.bytesToStr(s1).split(':')[0];
  var k2 = AES.strToBytes(r2);
  var s2 = AES.decryptCBC(b64ToBytes(mid), k2, k2);
  return AES.bytesToUtf8(s2);
}

/* =========================================================================
 *  İnat API transport
 * ========================================================================= */
var GATEWAY = 'https://speedrestapi.com/rest/api/';
var POST_HEADERS = {
  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
  'User-Agent': 'speedrestapi',
  'Referer': 'https://speedrestapi.com/',
  'X-Requested-With': 'com.bp.box'
};

function randKey() {
  var c = 'abcdefghijklmnopqrstuvwxyz0123456789', k = '';
  for (var i = 0; i < 16; i++) k += c.charAt(Math.floor(Math.random() * c.length));
  return k;
}

/* POST an İnat endpoint, return decrypted+parsed JSON (array or object). */
async function inatApi(url) {
  var key = randKey();
  var res = await fetch(url, {
    method: 'POST',
    headers: POST_HEADERS,
    body: '1=' + key + '&0=' + key
  });
  var txt = await res.text();
  if (!txt) throw new Error('empty response from ' + url);
  var dec = inatDecrypt(txt, key);
  return JSON.parse(dec);
}

/* ---- bootstrap + category discovery (self-healing against domain changes) */
var _ctUrl = null;        // discovered ct.php url
var _cats = null;         // discovered categories array

async function ctUrl() {
  if (_ctUrl) return _ctUrl;
  var dc = await inatApi(GATEWAY);
  _ctUrl = dc && dc.DC2 ? dc.DC2 : 'https://dizilabmedia.click/CDN/001/002/dizilab/v2/ct.php';
  return _ctUrl;
}

async function categories() {
  if (_cats) return _cats;
  var url = await ctUrl();
  _cats = await inatApi(url);
  return _cats;
}

/* scraperId -> İnat category display name (as returned by ct.php). */
var CAT = {
  inat_tv_list1:    'Liste 1 - TR',
  inat_tv_list2:    'Liste 2 - GLB',
  inat_tv_list3:    'Liste 3 - TR',
  inat_spor:        'Spor',
  inat_derbiler:    'Derbiler',
  inat_sinema:      'Sinema',
  inat_belgesel:    'Belgesel',
  inat_ulusal:      'Ulusal',
  inat_haber:       'Haber',
  inat_eba:         'EBA TV',
  inat_cocuk:       'Çocuk',
  inat_dini:        'Dini',
  inat_mubi:        'Mubi',
  inat_yerlifilm:   'Yerli Filmler',
  inat_exxen:       'EXXEN',
  inat_gain:        'Gain',
  inat_netflix:     'Netflix',
  inat_hbo:         'HBO Max - (BLUTV)',
  inat_disney:      'Disney+',
  inat_amazon:      'Amazon Prime',
  inat_tabii:       'Tabii',
  inat_tod:         'TOD',
  inat_yabancidizi: 'Yabancı Diziler',
  inat_yerlidizi:   'Yerli Diziler',
  inat_4k01exo:     '4K Film 01 | Exo',
  inat_4k01web:     '4K Film 01 | Web',
  inat_4k02web:     '4K Film 02 | Web',
  inat_4k03exo:     '4K Film 03 | Exo',
  inat_4k03web:     '4K Film 03 | Web',
  inat_4k04exo:     '4K Film 04 | Exo',
  inat_4k04web:     '4K Film 04 | Web',
  inat_4k06exo:     '4K Film 06 | Exo',
  inat_4k06web:     '4K Film 06 | Web',
  inat_4k07web:     '4K Film 07 | Web'
};

function scraperId() {
  try { if (typeof SCRAPER_ID !== 'undefined' && SCRAPER_ID) return SCRAPER_ID; } catch (e) {}
  try { if (typeof globalThis !== 'undefined' && globalThis.SCRAPER_ID) return globalThis.SCRAPER_ID; } catch (e) {}
  return 'inat_netflix';
}

/* Find the current content URL for this scraper's category by name. */
async function categoryUrl(sid) {
  var want = CAT[sid];
  var list = await categories();
  for (var i = 0; i < list.length; i++) {
    if (list[i] && list[i].catName === want) return list[i].catUrl;
  }
  // tolerant fallback: case-insensitive / trimmed match
  var w = (want || '').toLowerCase().replace(/\s+/g, '');
  for (var j = 0; j < list.length; j++) {
    var n = (list[j] && list[j].catName || '').toLowerCase().replace(/\s+/g, '');
    if (n === w) return list[j].catUrl;
  }
  throw new Error('category not found: ' + want);
}

/* =========================================================================
 *  Node <-> id helpers.  The id is just a JSON string carrying what the
 *  next step needs; it round-trips through the engine's JSON call args.
 * ========================================================================= */
function enc(node) { return JSON.stringify(node); }
function dec(id) {
  try { return JSON.parse(id); } catch (e) { return null; }
}

/* Normalise one İnat entry (category item / series / season / episode). */
function readEntry(e) {
  var name = e.diziName || e.chName || e.catName || '';
  var img = e.diziImg || e.chImg || e.catImg || '';
  var url = e.diziUrl || e.chUrl || e.catUrl || '';
  var type = e.diziType || e.chType || e.catType || '';
  return { name: name, img: img, url: url, type: type, raw: e };
}

/* A "folder" is something we must drill into (series / season / sub-list). */
function isFolder(en) {
  if (en.raw.chUrl || en.raw.chReg) return false;         // playable leaf
  if ((en.type || '').indexOf('dizi_mode') >= 0) return true;
  if (en.raw.diziUrl || en.raw.catUrl) return true;
  return false;
}
function isSkippable(en) {
  var t = en.type || '';
  return t.indexOf('link_mode') >= 0 || t.indexOf('destek_mode') >= 0 ||
         /^@/.test(en.name) || !en.url;
}

/* =========================================================================
 *  getCatalog — top level of one category
 * ========================================================================= */
async function getCatalog(args) {
  var sid = scraperId();
  var catUrl = await categoryUrl(sid);
  var list = await inatApi(catUrl);
  if (!Array.isArray(list)) list = [];

  var q = (args && args.query ? String(args.query) : '').toLowerCase().trim();
  var items = [];
  for (var i = 0; i < list.length; i++) {
    var en = readEntry(list[i]);
    if (isSkippable(en)) continue;
    if (q && en.name.toLowerCase().indexOf(q) < 0) continue;

    var folder = isFolder(en);
    var node = folder
      ? { f: 1, u: en.url, n: en.name }
      : { cu: en.raw.chUrl || en.url, cr: en.raw.chReg || null, ch: en.raw.chHeaders || null, n: en.name };

    items.push({
      id: enc(node),
      name: en.name,
      poster: en.img || null,
      type: folder ? 'tv' : 'movie',
      description: en.raw.diziDetay || ''
    });
  }
  return { items: items };
}

/* search is handled through getCatalog's query arg (engine convention). */
async function search(args) { return getCatalog(args); }

/* =========================================================================
 *  getMeta — drill a folder (series) into a flat episode list.
 *  Handles the series -> seasons -> episodes chain recursively.
 * ========================================================================= */
async function collectEpisodes(url, prefix, depth, out) {
  if (depth > 4) return;
  var list;
  try { list = await inatApi(url); } catch (e) { return; }
  if (!Array.isArray(list)) return;

  for (var i = 0; i < list.length; i++) {
    var en = readEntry(list[i]);
    if (isSkippable(en)) continue;

    if (!isFolder(en)) {
      // leaf / episode
      var title = prefix ? (prefix + ' · ' + en.name) : en.name;
      out.push({
        id: enc({ cu: en.raw.chUrl || en.url, cr: en.raw.chReg || null, ch: en.raw.chHeaders || null, n: title }),
        title: title,
        _img: en.img || null
      });
    } else {
      // season / sub-folder -> recurse, carrying its name as prefix
      var p = prefix ? (prefix + ' · ' + en.name) : en.name;
      await collectEpisodes(en.url, p, depth + 1, out);
    }
  }
}

async function getMeta(args) {
  var node = dec(args && args.id);
  if (!node || !node.u) return { meta: null };

  var eps = [];
  await collectEpisodes(node.u, '', 0, eps);

  var videos = [];
  for (var i = 0; i < eps.length; i++) {
    videos.push({
      id: eps[i].id,
      title: eps[i].title,
      season: 1,
      episode: i + 1,
      thumbnail: eps[i]._img || null
    });
  }
  return {
    meta: {
      id: args.id,
      type: 'series',
      name: node.n || 'İnat',
      videos: videos
    }
  };
}

/* =========================================================================
 *  getStreams — resolve one leaf (channel / episode) to a playable URL.
 * ========================================================================= */
function playHeaders(ch) {
  var h = {};
  var src = (ch && ch[0]) ? ch[0] : (ch || {});
  if (src.UserAgent) h['User-Agent'] = src.UserAgent;
  if (src.Referer) h['Referer'] = src.Referer;
  if (src.XRequestedWith) h['X-Requested-With'] = src.XRequestedWith;
  if (!h['User-Agent']) h['User-Agent'] =
    'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko infoapp) Chrome/83.0.4103.60 Mobile Safari/537.36';
  return h;
}

function fetchHeaders(ch) {
  var h = playHeaders(ch);
  var o = { 'User-Agent': h['User-Agent'] };
  if (h['Referer']) o['Referer'] = h['Referer'];
  if (h['X-Requested-With']) o['X-Requested-With'] = h['X-Requested-With'];
  return o;
}

function mkStream(name, url, headers) {
  var isHls = /\.m3u8(\?|$)/i.test(url) || /master|playlist/i.test(url);
  return {
    name: name || 'İnat',
    title: name || 'İnat',
    url: url,
    streamUrl: url,
    type: isHls ? 'hls' : 'mp4',
    headers: headers
  };
}

async function getStreams(tmdbId, mediaType, season, episode, url) {
  var node = dec(url || tmdbId);
  if (!node) return [];

  // A folder id reached getStreams (movie-typed series) — resolve first leaf.
  if (node.f || node.u) {
    var eps = [];
    await collectEpisodes(node.u, '', 0, eps);
    if (!eps.length) return [];
    node = dec(eps[0].id);
    if (!node) return [];
  }

  var chUrl = node.cu;
  if (!chUrl) return [];
  var name = node.n || 'İnat';
  var reg = node.cr;
  var ph = playHeaders(node.ch);

  // Direct stream (no resolver regex): play as-is.
  if (!reg || !reg.length || !reg[0] || (!reg[0].Regex1 && !reg[0].Regex2)) {
    return [mkStream(name, chUrl, ph)];
  }

  // Resolver: GET the chUrl, decrypt the blob with Regex1 then Regex2.
  var r = reg[0];
  var streams = [];
  try {
    var res = await fetch(chUrl, { method: 'GET', headers: fetchHeaders(node.ch) });
    var blob = await res.text();
    if (blob) {
      var out = streamDecrypt(blob, r.Regex1, r.Regex2);
      var obj = null;
      try { obj = JSON.parse(out); } catch (e) {}
      var m3u8 = obj && obj.chUrl ? obj.chUrl : null;
      if (!m3u8) {
        var mm = out.match(/https?:\/\/[^"'\\\s]+\.m3u8[^"'\\\s]*/);
        if (mm) m3u8 = mm[0];
      }
      if (m3u8) streams.push(mkStream(name, m3u8, ph));
    }
  } catch (e) {
    console.error('inat getStreams resolve error:', e && e.message ? e.message : e);
  }

  // Fallback: if the resolver produced nothing, offer the raw chUrl.
  if (!streams.length) streams.push(mkStream(name, chUrl, ph));
  return streams;
}

/* =========================================================================
 *  exports
 * ========================================================================= */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { getCatalog: getCatalog, getMeta: getMeta, getStreams: getStreams, search: search };
}
if (typeof globalThis !== 'undefined') {
  globalThis.getCatalog = getCatalog;
  globalThis.getMeta = getMeta;
  globalThis.getStreams = getStreams;
  globalThis.search = search;
}
