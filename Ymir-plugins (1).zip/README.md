# Nuvio Turkish Streaming Plugins

Turkish movie and series providers for the [Nuvio](https://nuvio.tv) Android TV app.

## 📲 Nuvio'ya Kurulum

Nuvio uygulamasını açın → **Eklentiler** → sağ üstteki **+** butonuna basın → şu URL'yi yapıştırın:

```
https://YOUR_GITHUB_USERNAME.github.io/nuvio-plugins/manifest.json
```

## 🎬 Kaynaklar (8 Provider)

| Provider | İçerik | Site |
|---|---|---|
| HDFilmCehennemi | Film + Dizi | hdfilmcehennemi.nl |
| DiziBox | Dizi | dizibox.live |
| FilmMakinesi | Film | filmmakinesi.de |
| FilmEkseni | Film | filmekseni.net |
| DiziBal | Dizi | dizibal.net |
| DiziYou | Dizi | diziyou.co |
| DexterPW | Film + Dizi | dexter.pw |
| RareFilm | Klasik Film | rarefilmm.com |

## 🏗️ Repo Yapısı

```
nuvio-plugins/
├── .github/workflows/deploy.yml   ← GitHub Pages otomatik deploy
├── providers/
│   ├── hdfilmcehennemi.js
│   ├── dizibox.js
│   ├── filmmakinesi.js
│   ├── filmekseni.js
│   ├── dizibal.js
│   ├── diziyou.js
│   ├── dexterpw.js
│   └── rarefilm.js
├── images/
│   └── icon.png
├── manifest.json
├── domains.json
└── README.md
```

## ⚙️ Kurulum Adımları (Repo)

1. GitHub'da yeni public repo oluştur (`nuvio-plugins`)
2. Bu dosyaları push et
3. Repo Settings → Pages → Source: **GitHub Actions** seç
4. `YOUR_GITHUB_USERNAME` yazan yerleri kendi kullanıcı adınla değiştir:
   - `manifest.json` → `baseUrl` ve `author`
   - Her `.js` dosyasındaki `DOMAINS_URL` satırı
5. Push yap → Actions çalışır → birkaç dakikada yayına girer

## 🔧 Domain Güncelleme

Bir sitenin domain'i değişirse `domains.json` dosyasını güncelle ve push et.
Otomatik deploy tetiklenir.

## 📝 Notlar

- Tüm provider'lar obfuscation olmadan temiz JavaScript ile yazılmıştır
- QuickJS (Nuvio'nun JS motoru) ile tam uyumludur
- `DOMAINS` global'i Nuvio tarafından inject edilirse o kullanılır, yoksa repo'dan çekilir
